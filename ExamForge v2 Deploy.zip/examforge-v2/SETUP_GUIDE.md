# ExamForge v2 — Setup Guide
**By Jay Tee (Mahoney Jude Tetteh)**
Do all of this on your phone. Takes about 15 minutes.

---

## STEP 1 — Get your FREE Gemini API Key (2 min)
1. Open: **aistudio.google.com/app/apikey**
2. Sign in with any Gmail account
3. Tap "Create API key" → Copy it (starts with AIza...)
4. Save it somewhere (Notes app)

---

## STEP 2 — Set up Supabase FREE database (5 min)
1. Open: **supabase.com** → tap "Start your project" → sign up free
2. Tap "New project" → name it `examforge` → set any password → Create
3. Wait ~1 minute for it to load
4. Go to **SQL Editor** (left sidebar) → tap "New query"
5. Paste this SQL and tap "Run":

```sql
create table users (
  id uuid default gen_random_uuid() primary key,
  email text unique not null,
  name text not null,
  password_hash text not null,
  joined_at timestamp default now()
);

create table visits (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references users(id),
  email text,
  name text,
  type text,
  created_at timestamp default now()
);

create table history (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references users(id),
  course text,
  guide text,
  created_at timestamp default now()
);
```

6. Go to **Settings → API** (left sidebar)
7. Copy your **Project URL** (looks like: https://xxxx.supabase.co)
8. Copy your **service_role secret key** (under "Project API keys" — tap "reveal")
9. Save both in Notes

---

## STEP 3 — Upload to GitHub (3 min)
1. Open: **github.com** → create free account
2. Tap "+" → "New repository" → name: `examforge` → Public → Create
3. Tap "uploading an existing file"
4. Upload ALL files keeping this exact structure:
   ```
   api/auth.js
   api/generate.js
   api/history.js
   public/index.html
   package.json
   vercel.json
   ```
5. Tap "Commit changes"

---

## STEP 4 — Deploy on Vercel (2 min)
1. Open: **vercel.com** → sign up with GitHub (free)
2. Tap "Add New Project" → select `examforge` → tap "Deploy"
3. Wait ~1 minute

---

## STEP 5 — Add your secret keys to Vercel (2 min)
1. In Vercel dashboard → tap your project → Settings → Environment Variables
2. Add these one by one:

| Name | Value |
|------|-------|
| GEMINI_API_KEY | your key from Step 1 |
| SUPABASE_URL | your URL from Step 2 |
| SUPABASE_SERVICE_KEY | your service key from Step 2 |
| PASSWORD_SALT | type any random word e.g. `examforge2025` |

3. Tap "Save" after each one
4. Go to Deployments tab → tap "Redeploy"

---

## DONE! 🎉
Your site is live at: **https://examforge.vercel.app**

Share that link with students!

---

## How to see who signed up (your student list)
1. Go to supabase.com → your project
2. Click "Table Editor" → click "users" table
3. You'll see every student's name, email, and when they joined ✅

